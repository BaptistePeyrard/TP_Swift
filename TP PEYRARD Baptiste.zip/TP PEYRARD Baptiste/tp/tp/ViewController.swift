//
//  ViewController.swift
//  tp
//
//  Created by Baptiste Peyrard on 07/12/2021.
//

import UIKit

//Vue pour la liste des taches
class ViewController: UIViewController, UITableViewDataSource, UISearchBarDelegate {
    
    //TableView
    @IBOutlet weak var ListeTitre: UITableView!
    //Barre de recherche
    @IBOutlet weak var searchBar: UISearchBar!
    //Label avec le nom de la catégorie
    @IBOutlet weak var nameCatgeorie: UILabel!
    //Liste des taches complete
    var liste: TodoList?
    //Liste des taches filrés par la barre de recherche
    var filteredListe: TodoList?
    //Variable bool qui renvoie true si l'utilisateur utilise la barre de recherche
    var searchIni: Bool = false

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchIni == false {
            return liste!.getListe().count
        }
        else{
            return filteredListe!.getListe().count
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        liste!.triListe()
        filteredListe!.triListe()
        let cell = tableView.dequeueReusableCell(withIdentifier:"cellContent", for: indexPath) as! TableViewCell
        let row = indexPath.row
        var todo: Todo
        //On recupere liste ou filteredListe en fonction de si l'utilisateur utilise la barre de recherche
        if searchIni == false {
           todo = liste!.getListe()[row]
        }
        else{
            todo = filteredListe!.getListe()[row]
        }
        //On remplit les labels
        cell.titre.text = todo.getTitle()
        cell.date.text = todo.getStringDate()
        //On remplit le texte du bouton pour changer le status
        cell.status.tag = row
        if todo.getStatus() == false{
            cell.status.setTitle("A faire",for: .normal)
        }
        else{
            cell.status.setTitle("Faite", for: .normal)
        }
        
        return cell
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Attribution du nom de la catégorie dans le label
        nameCatgeorie.text = liste?.getCategorie()
        let filteredtodos = liste?.getListe()
        filteredListe?.setListe(todoList: filteredtodos!)
        searchBar.delegate = self
        ListeTitre.dataSource = self
        ListeTitre.reloadData()
    }
    
    //Fonction prepare pour l'envoi dans la vue Description de la tache séléctionnée
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? DescriptionViewController {
            let row = ListeTitre.indexPathForSelectedRow!.row
            if searchIni == false {
            vc.data = liste!.getListe()[row]
            }
            else{
            vc.data = filteredListe!.getListe()[row]
            }
        }
    }
 
    //Fonction cancel pour annuler un ajout en cours
    @IBAction func cancel(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? ModifierViewController{
            vc.dismiss(animated: true, completion: nil)
        }
    }
     
    //Fonction save pour sauvegarder un ajout
    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? AjoutViewController{
            liste!.ajouterTodo(todo: vc.data)
            ListeTitre.reloadData()
        }
    }
    
    //Fonction supprimer pour supprimer une tache de la catégorie
    @IBAction func supprimer(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? DescriptionViewController{
            liste!.supprimerTodo(todo: vc.data!)
            filteredListe!.supprimerTodo(todo: vc.data!)
            ListeTitre.reloadData()
        }
    }
    
    //Fontion pour actualiser le tableau à chaque fois qu'on revient sur la vue
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ListeTitre.reloadData()
    }
    
    //Action du bouton pour changer le status
    @IBAction func ChangerStatus(_ sender: UIButton) {
        let row = sender.tag
        if searchIni == false {
            liste!.getListe()[row].InverserStatus()
        }
        else{
            filteredListe!.getListe()[row].InverserStatus()
        }
        //On reload pour changer l'affichage
        ListeTitre.reloadData()
    }
    
    //Fonction qui s'active à chaque changement dans la barre de recherche
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
        let filteredtodos = liste?.getListe()
        if searchText == "" {
            //La liste filtré se réinitialise sur la liste originalle
            filteredListe?.setListe(todoList: filteredtodos!)
            searchIni = false
        }
        else {
            //la liste filté se vide pour se remplir des taches qui ont un titre qui contient le texte entré par l'utilisateur
            filteredListe?.viderListe()
            for todo in liste!.getListe(){
                if todo.getTitle().lowercased().contains(searchText.lowercased()){
                    filteredListe?.ajouterTodo(todo: todo)
                }
                searchIni = true
            }
        }
        ListeTitre.reloadData()
    }
    
}


