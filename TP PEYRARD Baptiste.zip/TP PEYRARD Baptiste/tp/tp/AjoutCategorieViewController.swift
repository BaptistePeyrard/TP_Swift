//
//  AjoutCategorieViewController.swift
//  tp
//
//  Created by Baptiste Peyrard on 14/12/2021.
//

import UIKit

class AjoutCategorieViewController: UIViewController, UITextFieldDelegate {

    //Champ à remplir avec le nom de la catégorie
    @IBOutlet weak var Ajout_Nom: UITextField!
    //Variable contenant le nom
    var nom: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        Ajout_Nom.text = "titre"
        Ajout_Nom.delegate = self
    }
    
    //Pour pouvoir quitter le clavier avec return et attribuer la valeur à nom
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        nom = Ajout_Nom.text!
        return true
    }
    

}
