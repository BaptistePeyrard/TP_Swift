//
//  DescriptionViewController.swift
//  tp
//
//  Created by Baptiste Peyrard on 12/12/2021.
//

import UIKit

class DescriptionViewController: UIViewController {

    //Labels affichant les infos sur la tache
    @IBOutlet weak var titre: UILabel!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var date: UILabel!
    //Variable contenant la tache
    var data: Todo?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //On recupere les valeurs pour chaque label
        if let todo = data{
            titre.text = todo.getTitle()
            desc.text = todo.getDesc()
            date.text = todo.getStringDate()
        }
        else{
            titre.text = "Error"
            desc.text = ""
        }
    }
    
    //Fonction prepare pour pouvoir modifier la tache
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? ModifierViewController {
            vc.data = data
        }
    }
    
    //Fonction cancel pour annuler une modification
    @IBAction func cancel(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? ModifierViewController{
            vc.dismiss(animated: true, completion: nil)
        }
    }
    
    //Fonction save pour sauvegarder une modification
    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? ModifierViewController{
            if let updatedtodo = vc.data {
                titre.text = updatedtodo.getTitle()
                desc.text = updatedtodo.getDesc()
                date.text = updatedtodo.getStringDate()
                data?.setTitle(title: updatedtodo.getTitle())
                data?.setDesc(desc: updatedtodo.getDesc())
                data?.setDate(date: updatedtodo.getDate())
                
            }
        }
    }
    

}
