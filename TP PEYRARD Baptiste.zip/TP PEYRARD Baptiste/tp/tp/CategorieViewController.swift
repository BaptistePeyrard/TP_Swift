//
//  CategorieViewController.swift
//  tp
//
//  Created by Baptiste Peyrard on 13/12/2021.
//

import UIKit

class CategorieViewController: UIViewController, UITableViewDataSource {
    
    //TableView
    @IBOutlet weak var Liste_Categorie: UITableView!
    //Liste des catégories à afficher dans le TableView
    var listesCategorie: [TodoList] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listesCategorie.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        let cell = tableView.dequeueReusableCell(withIdentifier:"CategorieCellContent", for: indexPath) as! CategorieTableViewCell
        let row = indexPath.row
        //Labels à remplir pour chaque cellule
        cell.NameCategorie.text = listesCategorie[row].getCategorie()
        cell.nbrTodos.text = String(listesCategorie[row].getListe().count)
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Création de plusieurs taches pour visualiser les taches
        
        //On utilise DateComponent pour modifier la date et Calendar pour le convertir en Date
        let userCalendar = Calendar(identifier: .gregorian)
        var component = DateComponents()
        component.year = 2021
        component.month = 12
        component.day = 1
        component.hour = 15
        let date1 = userCalendar.date(from: component)
        var component2 = DateComponents()
        component2.year = 2021
        component2.month = 11
        component2.day = 15
        component2.hour = 12
        let date2 = userCalendar.date(from: component2)
        var component3 = DateComponents()
        component3.year = 2021
        component3.month = 11
        component3.day = 15
        component3.hour = 10
        let date3 = userCalendar.date(from: component3)
        var component4 = DateComponents()
        component4.month = 12
        component4.year = 2021
        component4.day = 15
        component4.hour = 10
        let date4 = userCalendar.date(from: component4)
        var component5 = DateComponents()
        component5.month = 1
        component5.year = 2022
        component5.day = 6
        component5.hour = 18
        let date5 = userCalendar.date(from: component5)
        
        let todo1 = Todo(title: "Rendre Projet",desc: "Code et compte rendu", date: date1!)
        let todo2 = Todo(title: "Préparer réunion",desc: "Emmener Ordi", date: date2!)
        let todo3 = Todo(title: "Finir exercices",desc: "Exercices 2 et 3", date: date3!)
        let todo4 = Todo(title: "Aller faire les courses",desc: "Lait, Fromage, Lardons, Pâtes", date: date4!)
        let todo5 = Todo(title: "Payer Loyer",desc: "400€", date: date5!)
        let liste = TodoList(categorie: "Travail")
        liste.ajouterTodo(todo: todo1)
        liste.ajouterTodo(todo: todo2)
        liste.ajouterTodo(todo: todo3)
        let liste2 = TodoList(categorie: "Perso")
        liste2.ajouterTodo(todo: todo4)
        liste2.ajouterTodo(todo: todo5)
        
        listesCategorie.append(liste)
        listesCategorie.append(liste2)
        Liste_Categorie.dataSource = self
    }
    
    //Fonction prepare pour l'envoi dans la vue des Taches de la catégorie séléctionné (ViewController)
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? ViewController {
            let row = Liste_Categorie.indexPathForSelectedRow!.row
            //Envoi des données dans la liste
            vc.liste = listesCategorie[row]
            //Création et envoi d'une nouvelle liste pour la liste filtré qui ne doit pas être la même que la liste classique
            let car = listesCategorie[row].getCategorie()
            let newliste = TodoList(categorie: car)
            let todos = listesCategorie[row].getListe()
            newliste.setListe(todoList: todos)
            vc.filteredListe = newliste
        }
    }

    //Action save pour sauvegarder la nouvelle catégorie depuis AjoutCategorieViewController
    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        if let vc = unwindSegue.source as? AjoutCategorieViewController{
            let newliste = TodoList(categorie: vc.nom)
            listesCategorie.append(newliste)
            Liste_Categorie.reloadData()
        }
    }
    
    //Fontion pour actualiser le tableau à chaque fois qu'on revient sur la vue
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Liste_Categorie.reloadData()
    }

}
