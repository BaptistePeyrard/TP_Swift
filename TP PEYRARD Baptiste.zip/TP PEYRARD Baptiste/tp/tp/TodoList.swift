//
//  TodoList.swift
//  tp
//
//  Created by Baptiste Peyrard on 07/12/2021.
//

import Foundation

class TodoList{
    
    var _categorie:String
    var _todos = [Todo]()
    
    //Constructeur
    init(categorie:String){
        self._categorie = categorie
    }
    
    //Ajouter une tache à la liste
    func ajouterTodo(todo:Todo){
        _todos.append(todo)
    }
    
    func getCategorie() -> String{
        return _categorie
    }
    
    func getListe() -> [Todo]{
        return _todos
    }
    
    func setListe(todoList: [Todo]){
        self.viderListe()
        for todo in todoList{
            self.ajouterTodo(todo: todo)
        }

    }
    
    //Trier la liste par date croissante
    func triListe(){
        _todos.sort(by :{ $0.getDate().compare($1.getDate()) == .orderedAscending })
    }
    
    //Recuperer l'index de la tache (utile pour supprimer une tache)
    func getIndex(todo: Todo) -> Int{
        var row = 0
        var compteur = 0
        for i in _todos{
            if (todo.getTitle() == i.getTitle()) && (todo.getDesc() == i.getDesc()){
                row = compteur
            }
            compteur = compteur + 1
        }
        return row
    }
    
    //Supptimer la tache de la liste
    func supprimerTodo(todo:Todo){
        let row = getIndex(todo: todo)
        self._todos.remove(at: row)
    }
    
    //Vider la liste (utile pour le filtre de la recherche)
    func viderListe(){
        for todo in _todos {
            supprimerTodo(todo: todo)
        }
    }
    
}
