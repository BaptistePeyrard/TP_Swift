//
//  CategorieTableViewCell.swift
//  tp
//
//  Created by Baptiste Peyrard on 13/12/2021.
//

import UIKit

class CategorieTableViewCell: UITableViewCell {

    //Labels dans les cellules
    @IBOutlet weak var NameCategorie: UILabel!
    @IBOutlet weak var nbrTodos: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
