//
//  Todo.swift
//  tp
//
//  Created by Baptiste Peyrard on 07/12/2021.
//

import Foundation

class Todo{
    
    var _title:String
    var _desc:String
    var _date: Date
    var _status:Bool
    
    //Constructeur
    init(title:String, desc:String, date:Date){
        self._title = title
        self._desc = desc
        self._status = false    //False = a faire
        self._date = date
    }
    
    func getTitle() -> String{
        return self._title
    }
    func getDesc() -> String{
        return self._desc
    }
    
    func getStatus() -> Bool{
        return self._status
    }
    func getDate() -> Date{
        return self._date
    }
    
    //Pour pouvoir afficher la date dans un label
    func getStringDate() -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy HH:mm"
        let date = formatter.string(from: self.getDate())
        return date
    }
    
    func setTitle(title:String){
        self._title = title
    }
    func setDesc(desc:String){
        self._desc = desc
    }
    
    func setDate(date:Date){
        self._date = date
    }
    
    func InverserStatus(){
        if self._status == true{
            self._status = false
        }
        else{
            self._status = true
        }
    }
    
    
    
}
