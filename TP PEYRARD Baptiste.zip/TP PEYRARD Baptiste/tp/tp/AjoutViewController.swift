//
//  AjoutViewController.swift
//  tp
//
//  Created by Baptiste Peyrard on 12/12/2021.
//

import UIKit

//Vue pour ajouter une tache
class AjoutViewController: UIViewController, UITextFieldDelegate {

    //Champs à remplir
    @IBOutlet weak var Ajout_Titre: UITextField!
    @IBOutlet weak var Ajout_Desc: UITextField!
    //DatePicker pour choisir une date
    @IBOutlet weak var Ajout_Date: UIDatePicker!
    //Variable contenant la nouvelle tache
    var data = Todo(title: "titre", desc: "desc", date: Date())
    
    override func viewDidLoad() {
        super.viewDidLoad()

        Ajout_Titre.text = "Titre"
        Ajout_Desc.text = "Description"
        Ajout_Date.date = Date()
        
        Ajout_Titre.delegate = self
        Ajout_Desc.delegate = self
    }
    
    //Pour pouvoir quitter le clavier avec return et attribuer les valeurs à data
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        data.setTitle(title: Ajout_Titre.text!)
        data.setDesc(desc: Ajout_Desc.text!)
        return true
    }
    
    //Action pour recuperer la date choisie si la valeur du datePicker est modifié
    @IBAction func DatePickerUpdate(_ sender: UIDatePicker) {
        data.setDate(date: Ajout_Date.date)
    }
    

}
