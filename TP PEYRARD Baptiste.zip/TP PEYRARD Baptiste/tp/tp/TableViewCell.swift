//
//  TableViewCell.swift
//  tp
//
//  Created by Baptiste Peyrard on 07/12/2021.
//

import UIKit

//TableViewCell de la liste de taches
class TableViewCell: UITableViewCell {

    //Elements dans la cellule
    @IBOutlet weak var titre: UILabel!
    @IBOutlet weak var status: UIButton!
    @IBOutlet weak var date: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
