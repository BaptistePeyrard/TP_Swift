//
//  ModifierViewController.swift
//  tp
//
//  Created by Baptiste Peyrard on 12/12/2021.
//

import UIKit

//Vue pour modifier une tache
class ModifierViewController: UIViewController, UITextFieldDelegate {

    //Champs à remplir
    @IBOutlet weak var Modif_Titre: UITextField!
    @IBOutlet weak var Modif_Desc: UITextField!
    //DatePicker pour choisir une date
    @IBOutlet weak var Modif_Date: UIDatePicker!
    //Variable contenant la tache
    var data: Todo?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Les elements vont prendre les anciennes valeurs de la tache à modifier
        if let todo = data {
            Modif_Titre.text = todo.getTitle()
            Modif_Desc.text = todo.getDesc()
            Modif_Date.date = todo.getDate()
        }
        
        Modif_Titre.delegate = self
        Modif_Desc.delegate = self
    }
    
    //Pour pouvoir quitter le clavier avec return et attribuer les valeurs à data
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        data!.setTitle(title: Modif_Titre.text!)
        data!.setDesc(desc: Modif_Desc.text!)
        return true
    }
    
    //Action pour recuperer la date choisie si la valeur du datePicker est modifié
    @IBAction func DatePickerUpdate(_ sender: UIDatePicker) {
        data!.setDate(date: Modif_Date.date)
    }
}
